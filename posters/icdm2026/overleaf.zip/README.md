# ARRL at IEEE ICDM 2026 - S16207

One-Shot Domain Calibration of Mixture-of-Experts Routers via Gradient Bias Steering

## Ready PDF

`S16207.pdf` is a single-page portrait poster, exactly **33.1 x 46.8 inches**
(840.74 x 1188.72 mm). Fonts are embedded. Text, tables, diagrams and the QR are vector.
The paper ID is printed in the bottom-right corner.

## Overleaf

Upload this ZIP as a new project. Select `main.tex` as the main document and
**pdfLaTeX** as the compiler. The complete editable source is `S16207.tex`;
there is no external custom style dependency. Logo assets are in `assets/`.

For local compilation:

```sh
latexmk -pdf main.tex
```

The distributed PDF was compiled with Tectonic (XeTeX).

## Changes from the supplied poster

- Adapted the latest supplied KDD TeX layout to the ICDM portrait dimensions.
- Replaced conference identity, location, workshop and paper ID.
- Used the official ICDM 2026 logo and a navy/blue palette.
- Kept the scientific data tables and plot coordinates unchanged.
- Kept all seven authors and their original KDD order at the user's explicit request.
- Restored the original Telegram contact: https://t.me/Turukmokto (@Turukmokto).
- GitHub QR links to the paper repository: https://github.com/CTLab-ITMO/MoE-One-Shot-Domain-Calibration.
- Added email esbessonn@gmail.com alongside the original Telegram contact.
- Restored the Telegram QR beside the GitHub QR, with its matching destination.

## Requirements and scope

The public ICDM instructions allow either landscape 46.8 x 33.1 inches or
portrait 33.1 x 46.8 inches, require the paper ID at bottom right, and request
PDF filenames `[accepted_paper_id].pdf`. Layout within the display area is flexible.
The title and ID were cross-checked against the acceptance notification.
Author ordering follows the user's choice, even where the notification differs.
This adaptation preserves the supplied poster's results; it is not a new audit
against a revised ICDMW camera-ready manuscript.

Public author instructions: https://icdm2026.neu.edu.cn/11664/list.htm
Official template folder: https://drive.google.com/drive/folders/1Ejv9SM4IyOoRhx5NGRSkeL0-PKDyNTn8
Official portrait template: https://docs.google.com/presentation/d/1wf1wU4R2qQieNMZnDYLxVg3v4gHRyWPis1zzd9H84m0/edit
Logo source: https://icdm2026.neu.edu.cn/_upload/tpl/02/82/642/template642/images/logo1.png

The public conference poster deadline is **October 12, 2026, AoE**. As of
October 15, that date has passed. Workshop-specific poster upload rules were
not found in the supplied camera-ready correspondence or the checked workshop
pages. Confirm the upload route/deadline with the workshop organizers before
submission. Nothing has been uploaded or emailed by this task.

Print at 100% / actual size if printing is requested by your workshop.

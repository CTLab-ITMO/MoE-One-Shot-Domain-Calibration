# DCRB poster for RelKD @ KDD 2026

Overleaf-ready one-page poster for **One-Shot Domain Calibration of MoE Routers via Gradient Bias Steering**, using the same visual template and physical format as the previous RelKD posters.

- **36 x 42 inches** (3 ft x 3.5 ft)
- **Portrait orientation**
- Main document: **`main.tex`**
- Default compiler: **pdfLaTeX**
- Also compatible with LuaLaTeX and XeLaTeX

## Overleaf

1. Create a project with **New Project -> Upload Project** and upload this ZIP.
2. In **Menu -> Main document**, select `main.tex`.
3. In **Menu -> Compiler**, select `pdfLaTeX`.
4. Click **Recompile from scratch**.

The project deliberately avoids an unconditional `fontspec` dependency. Under pdfLaTeX, the `noto` package uses Type 1 fonts; under XeLaTeX/LuaLaTeX it uses OpenType fonts.

## Local build

```bash
make
```

or

```bash
latexmk -pdf main.tex
```

## Project files

- `main.tex` - Overleaf entry point
- `poster.tex` - complete poster content and layout
- `posterstyle.sty` - typography, colors, and reusable poster components
- `assets/kdd2026_logo.jpg` - exact KDD 2026 raster logo supplied by the user
- `assets/itmo_logo_black.png` - ITMO logo
- `assets/github_qr.png` - QR code to the public GitHub profile used in the previous poster template
- `assets/contact_qr.png` - QR code to the Telegram contact used in the previous poster template

## QR destinations

- GitHub: `https://github.com/lodre`
- Contact: `https://t.me/iodre`

The supplied manuscript does not identify a public implementation repository for this paper, so the GitHub QR is labelled as a public profile rather than as the paper's code repository.

## Printing

Print or export at **100% / actual size**. Do not use "fit to page". The PDF page box is already exactly 36 x 42 inches.
